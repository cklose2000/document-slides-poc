"""
Integration tests package.

Contains tests that verify the interaction between multiple components
or modules within the application.
"""