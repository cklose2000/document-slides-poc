"""
API tests package.

Contains tests for API endpoints, request/response handling,
and external service integrations.
"""