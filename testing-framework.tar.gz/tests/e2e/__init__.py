"""
End-to-end tests package.

Contains tests that verify complete user workflows and
application behavior from start to finish.
"""